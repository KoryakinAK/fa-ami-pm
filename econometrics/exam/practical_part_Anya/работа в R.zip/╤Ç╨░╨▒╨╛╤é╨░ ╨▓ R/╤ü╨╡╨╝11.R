# оценивание ЛММР для С---------------------------------------------------------
getwd()
file.show('/Users/annamaslova/Ct.txt')
C <- read.table('/Users/annamaslova/Ct.txt',
                sep='',
                dec = ',',
                header = T)
C
# оценивание модели
Cmodel <- lm(data = C,
             C_t~Y_t.1+Cr_t+San_t+Real_t)

# результаты оценивания модели
summary(Cmodel)
# Multiple R-squared:  0.9928
# F-statistic: 505.5 on 3 and 11 DF
# p-value: 4.625e-12 гипотеза 3 о неуд спец-ции отвергается если в протоколе R велич p-value меньше чем 0,05 
# сл мы отвергаем гипотезу
# если больше то гипотеза может быть принята


# Adjusted R-squared:  0.9908 скоректированный коэф детерминации


# модификация "от общего к частному"-дедукция для С ------------------------------------
# 1 шаг
Cmodel <- lm(data = C,
             C_t~Y_t.1+Cr_t+San_t)
summary(Cmodel)
# 2 шаг
Cmodel2 <- lm(data = C,
             C_t~Y_t.1+Cr_t)
summary(Cmodel2)
# San_t - значащая перем - ее нельзя удалять (Adjusted R-squared стал меньше чем был изначально 0.9908)
# 3 шаг
Cmodel3 <- lm(data = C,
             C_t~Y_t.1+San_t)
summary(Cmodel3)
# Cr_t - значащая перем - ее нельзя удалять (Adjusted R-squared стал меньше чем был изначально 0.9908)








# оценивание ЛММР для I---------------------------------------------------------
# запись в объект R
# /Users/annamaslova/OneDrive - ФГОБУ ВО Финансовый университет при Правительстве РФ/эконометрика/работа в R
I <- read.table('/Users/annamaslova//It.txt',
                sep='',
                dec = ',',
                header = T)
I
Imodel <- lm(data = I,
             I~delta_Y_t+Cr_t+San_t+Real_t)
summary(Imodel)
# модификация "от общего к частному"-дедукция для I ------------------------------------
# 1 шаг - Cr_t
Imodel1 <- lm(data = I,
              I~delta_Y_t+San_t+Real_t)
summary(Imodel1)
# 2 шаг - San_t
Imodel2 <- lm(data = I,
             I~delta_Y_t+Cr_t+Real_t)
summary(Imodel2)
# 3 шаг - Cr_t & San_t
Imodel3 <- lm(data = I,
              I~delta_Y_t+Real_t)
summary(Imodel3)
# San_t - значащая перем - ее нельзя удалять (Adjusted R-squared стал меньше чем был изначально 0.9908)

# Cr_t - значащая перем - ее нельзя удалять (Adjusted R-squared стал меньше чем был изначально 0.9908)








# оценивание ЛММР для G---------------------------------------------------------
# запись в объект R
G <- read.table('/Users/annamaslova/OneDrive - ФГОБУ ВО Финансовый университет при Правительстве РФ/эконометрика/работа в R/Gt.txt',
                sep='',
                dec = ',',
                header = T)
G
Gmodel <- lm(data = G,
             G_t~0+G_t.1+Cr_t+San_t+Real_t)
summary(Gmodel)










# libraries ---------------------------------------------------------------
getwd()

library(ggplot2)
library(lmtest)
library(dplyr)
library(tseries)

# тестирование нормального закона распределения случайного возмуще --------
file.show('C:/Users/171069/Documents/U.txt')
U <- read.table('C:/Users/171069/Documents/U.txt',
                sep='',
                dec = ',',
                header = T)
U

U<-unlist(U)
jarque.bera.test(U1)
# Jarque Bera Test
# 
# data:  U1
# X-squared = 3.4529, df = 2, p-value = 0.1779
hist(U)
# та же самая штука -------------------------------------------------------
# изменим порядок тестеривания сл возхмущения и введем в Р все уравнения наблюдения
file.show('C:/Users/171069/Documents/PM.txt')
PM <- read.table('C:/Users/171069/Documents/PM.txt',
                sep='',
                dec = ',',
                header = T)
PM



PMmodel <- lm(data = PM,
              lnYL~lnKL)

# результаты оценивания модели
summary(PMmodel)
res <- residuals(PMmodel)
jarque.bera.test(res)
# Jarque Bera Test
# 
# data:  res
# X-squared = 3.4529, df = 2, p-value = 0.1779
# p value >0.05 гипотеза о нормальном законе распределения случайного возмущения принимается
hist(res)


# ДЗ ----------------------------------------------------------------------
# исследовать предположение о нормальном законе распределения в ДТЗ

# C DTZ -------------------------------------------------------------------
file.show('/Users/annamaslova/cdtz.txt')
Cdtz <- read.table('/Users/annamaslova/cdtz.txt',
                 sep='',
                 dec = ',',
                 header = T)
Cdtz

Cdtzmodel <- lm(data = Cdtz,
              C_t~Y_t.1+Cr_t+San_t+Real_t)

# результаты оценивания модели
summary(Cdtzmodel)
Cres <- residuals(Cdtzmodel)
jarque.bera.test(Cres)
# Jarque Bera Test
# 
# data:  Cres
# X-squared = 1.5789, df = 2, p-value = 0.4541

# p value >0.05 гипотеза о нормальном законе распределения случайного возмущения принимается
hist(Cres)

# I DTZ -------------------------------------------------------------------
file.show('/Users/annamaslova/Idtz.txt')
Idtz <- read.table('/Users/annamaslova/Idtz.txt',
                   sep='',
                   dec = ',',
                   header = T)
Idtz

Idtzmodel <- lm(data = Idtz,
                I~delta_Y_t+Cr_t+San_t+Real_t)

# результаты оценивания модели
summary(Idtzmodel)
Ires <- residuals(Idtzmodel)
jarque.bera.test(Ires)
# Jarque Bera Test
# 
# data:  Ires
# X-squared = 1.1163, df = 2, p-value = 0.5723

# p value >0.05 гипотеза о нормальном законе распределения случайного возмущения принимается
hist(Ires)




# G DTZ -------------------------------------------------------------------
file.show('/Users/annamaslova/Gdtz.txt')
Gdtz <- read.table('/Users/annamaslova/Gdtz.txt',
                   sep='',
                   dec = ',',
                   header = T)
Gdtz

Gdtzmodel <- lm(data = Gdtz,
                G_t~G_t.1+Cr_t+San_t+Real_t)

# результаты оценивания модели
summary(Gdtzmodel)
Gres <- residuals(Gdtzmodel)
jarque.bera.test(Gres)
# Jarque Bera Test
# 
# data:  Gres
# X-squared = 0.49628, df = 2, p-value = 0.7802

# p value >0.05 гипотеза о нормальном законе распределения случайного возмущения принимается
hist(Gres)

